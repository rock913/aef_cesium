"""
CH9 GEE 图层「白屏 / 黄色方块遮挡地球」根因修复
=================================================================

⚠️ 重要更正：`"format": "png"` 不是根因，甚至不是有效参数。

  GEE 的 getMapId() 视觉参数只接受 min / max / palette / bands / gain / bias / gamma /
  opacity / forceRgbOutput 等。传入 "format" 会被静默忽略。
  而且 —— GEE 瓦片本来就是 PNG，被 mask 掉的像元本来就是全透明的。
  所以加上 "format": "png" 不会修复任何东西，问题在别处。

真正的三个根因（按出现概率排序）：

  ① 【最可能】兜底分支返回了 ee.Image.constant() —— 它没有任何 mask
     CH8 原始代码：
         except: insar_img = ee.Image.constant(0).rename('velocity')...
     常量图在全球每一个像元都有值 → 全部通过 mask → 整个地球被一层纯色瓦片糊死。
     这就是你截图里的「纯黄色巨大方块」和「白屏」。
     Asset ID 没配 / 资产不存在 / 权限不足 → 必然触发。

  ② updateMask 的条件在常量图上恒为真
     prob.gt(0.72) 作用在一张 constant(1) 上 → 全 True → 满屏。

  ③ vis 里 min == max，或 palette 只有一个颜色 → 所有像元映射到同一色。

正确做法：**图层不可用时不要返回图层**，而不是返回一张假图。
后端返回 tileUrl=None，前端据此跳过 addImageryLayer —— 地球干干净净。
"""

import os
import ee


class LayerUnavailable(Exception):
    """图层不可用（资产缺失 / 权限不足 / 数据为空）。调用方据此跳过图层，不要兜底成常量图。"""

    def __init__(self, reason, hint=""):
        self.reason = reason
        self.hint = hint
        super().__init__(f"{reason} | {hint}")


def _require_asset(asset_id: str, expect_bands=None):
    """
    挂载 Asset 并做真实性校验。任何一步失败都抛 LayerUnavailable，
    绝不返回 ee.Image.constant() —— 那是白屏/色块的根源。
    """
    if not asset_id:
        raise LayerUnavailable("未配置 Asset ID", "检查环境变量，或前端应跳过该图层")
    try:
        img = ee.Image(asset_id)
        info = img.getInfo()          # 触发一次真实请求，资产不存在会在这里炸
    except Exception as e:
        raise LayerUnavailable(f"Asset 不可访问: {asset_id}", str(e)[:200])

    if not info or not info.get("bands"):
        raise LayerUnavailable(f"Asset 无波段: {asset_id}", "上传可能未完成")

    if expect_bands:
        have = {b["id"] for b in info["bands"]}
        miss = set(expect_bands) - have
        if miss:
            raise LayerUnavailable(f"Asset 缺少波段 {miss}", f"实际波段: {sorted(have)}")
    return img


def _guard_coverage(img, geometry, scale=100, max_ratio=0.92):
    """
    覆盖率护栏：掩膜后若仍覆盖 AOI 超过 92%，几乎可以断定 mask 失效
    （常量图、阈值写反、单位错等），此时宁可不出图也不要糊住地球。
    """
    try:
        total = ee.Image(1).reduceRegion(
            reducer=ee.Reducer.count(), geometry=geometry,
            scale=scale, maxPixels=1e8, bestEffort=True).values().get(0)
        valid = img.reduceRegion(
            reducer=ee.Reducer.count(), geometry=geometry,
            scale=scale, maxPixels=1e8, bestEffort=True).values().get(0)
        t = ee.Number(total).getInfo() or 0
        v = ee.Number(valid).getInfo() or 0
    except Exception:
        return                       # 统计失败不阻断主流程
    if t > 0 and (v / t) > max_ratio:
        raise LayerUnavailable(
            f"掩膜异常：覆盖率 {v/t:.1%} > {max_ratio:.0%}",
            "疑似常量图 / 阈值方向写反 / 单位不一致，已阻止其糊住地球",
        )


# ══════════════════════════════════════════════════════════════════
# CH9-B 古建单体形变体检
# ══════════════════════════════════════════════════════════════════
def layer_ch9_deformation(aoi_geom, params):
    asset_id = os.getenv("CH9_HERITAGE_INSAR_ASSET_ID", "")
    img = _require_asset(asset_id, expect_bands=["velocity", "coherence"])

    velocity = img.select("velocity")
    coherence = img.select("coherence")

    coh_thresh = float(params.get("coh_thresh", 0.75))
    defo_thresh = float(params.get("defo_thresh", 3.0))    # 古建比城市敏感，CH8 用 5.0

    masked = velocity.updateMask(
        coherence.gt(coh_thresh)
        .And(velocity.lt(-defo_thresh).Or(velocity.gt(defo_thresh)))
    )
    _guard_coverage(masked, aoi_geom)

    vis = {
        "min": -20, "max": 6,
        "palette": ["B03A2E", "C85F45", "C89A3C", "5DAE8B", "2E9CB8"],
        # 不写 format —— 无效参数。透明来自 updateMask，不来自这里。
    }
    return masked, vis, "ch9_heritage_deformation"


# ══════════════════════════════════════════════════════════════════
# CH9-C AEF 古建聚落零微调筛查
# ══════════════════════════════════════════════════════════════════
def layer_ch9_aef_discovery(aoi_geom, params):
    year = int(params.get("year", 2024))
    bands = [f"A{i:02d}" for i in range(64)]

    aef = (ee.ImageCollection("GOOGLE/SATELLITE_EMBEDDING/V1/ANNUAL")
           .filterDate(f"{year}-01-01", f"{year}-12-31")
           .filterBounds(aoi_geom)
           .first())
    if aef is None:
        raise LayerUnavailable(f"AEF {year} 年无数据", "AEF 覆盖 2017–2024")

    pos_id = os.getenv("CH9_AEF_POS_SAMPLES", "")
    neg_id = os.getenv("CH9_AEF_NEG_SAMPLES", "")
    if not pos_id or not neg_id:
        raise LayerUnavailable("AEF 训练样本资产未配置", "需先上传正/负样本 FeatureCollection")

    samples = ee.FeatureCollection(pos_id).merge(ee.FeatureCollection(neg_id))
    n = samples.size().getInfo()
    if n < 50:
        raise LayerUnavailable(f"训练样本仅 {n} 个", "至少需要 50 个，建议正 400 / 负 2000")

    training = aef.select(bands).sampleRegions(
        collection=samples, properties=["is_heritage"], scale=10, tileScale=4)

    clf = (ee.Classifier.libsvm(kernelType="LINEAR")
           .setOutputMode("PROBABILITY")
           .train(training, "is_heritage", bands))

    prob = aef.select(bands).classify(clf).rename("heritage_prob")
    thresh = float(params.get("prob_thresh", 0.72))
    masked = prob.updateMask(prob.gt(thresh))

    # 这一层最容易糊屏：分类器退化时会把整片区域判为高概率
    _guard_coverage(masked, aoi_geom, scale=200, max_ratio=0.55)

    vis = {"min": thresh, "max": 1.0,
           "palette": ["8A6B1F", "C89A3C", "F0C468"]}
    return masked, vis, "ch9_heritage_aef_discovery"


# ══════════════════════════════════════════════════════════════════
# CH9-D AEF 年际语义变化检测
# ══════════════════════════════════════════════════════════════════
def layer_ch9_change(aoi_geom, params):
    y0 = int(params.get("year_from", 2022))
    y1 = int(params.get("year_to", 2024))
    bands = [f"A{i:02d}" for i in range(64)]
    col = ee.ImageCollection("GOOGLE/SATELLITE_EMBEDDING/V1/ANNUAL").filterBounds(aoi_geom)

    a = col.filterDate(f"{y0}-01-01", f"{y0}-12-31").first()
    b = col.filterDate(f"{y1}-01-01", f"{y1}-12-31").first()
    if a is None or b is None:
        raise LayerUnavailable(f"AEF {y0} 或 {y1} 年无数据", "AEF 覆盖 2017–2024")

    # AEF 向量为单位长度 → 点积即余弦相似度
    dot = a.select(bands).multiply(b.select(bands)).reduce(ee.Reducer.sum())
    change = ee.Image(1).subtract(dot).rename("semantic_change")

    thresh = float(params.get("change_thresh", 0.25))
    masked = change.updateMask(change.gt(thresh))
    _guard_coverage(masked, aoi_geom, scale=100, max_ratio=0.45)

    vis = {"min": thresh, "max": 0.8,
           "palette": ["2E9CB8", "C89A3C", "C85F45", "B03A2E"]}
    return masked, vis, "ch9_heritage_change"


# ══════════════════════════════════════════════════════════════════
# 统一出口：把 LayerUnavailable 转成前端可识别的「跳过图层」响应
# ══════════════════════════════════════════════════════════════════
LAYER_REGISTRY = {
    "ch9_heritage_deformation":   layer_ch9_deformation,
    "ch9_heritage_aef_discovery": layer_ch9_aef_discovery,
    "ch9_heritage_change":        layer_ch9_change,
}


def get_layer(mode: str, aoi_geom, params: dict) -> dict:
    fn = LAYER_REGISTRY.get(mode)
    if fn is None:
        return {"tileUrl": None, "available": False,
                "reason": f"未知 mode: {mode}"}
    try:
        img, vis, suffix = fn(aoi_geom, params)
        mapid = img.getMapId(vis)
        return {
            "tileUrl": mapid["tile_fetcher"].url_format,
            "available": True,
            "suffix": suffix,
            "legend": vis,
            # 前端据此设置 ImageryLayer.alpha，不要写死 1.0
            "recommended_alpha": float(params.get("alpha", 0.85)),
        }
    except LayerUnavailable as e:
        # ★ 关键：不返回任何图层。前端必须跳过 addImageryLayer。
        return {"tileUrl": None, "available": False,
                "reason": e.reason, "hint": e.hint}
    except Exception as e:
        return {"tileUrl": None, "available": False,
                "reason": "GEE 执行异常", "hint": str(e)[:300]}
